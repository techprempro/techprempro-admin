package com.techprempro.techpremproadmin

import android.app.Activity
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.ViewGroup

class MainActivity:Activity(){
private lateinit var webView:WebView
private val dashboardUrl="https://techprempro.com/admin/dashboard"
override fun onCreate(savedInstanceState:Bundle?){
super.onCreate(savedInstanceState)
webView=WebView(this)
webView.layoutParams=ViewGroup.LayoutParams(-1,-1)
setContentView(webView)
val cookieManager=CookieManager.getInstance()
cookieManager.setAcceptCookie(true)
cookieManager.setAcceptThirdPartyCookies(webView,true)
cookieManager.flush()
webView.settings.javaScriptEnabled=true
webView.settings.domStorageEnabled=true
webView.settings.databaseEnabled=true
webView.settings.allowFileAccess=true
webView.settings.allowContentAccess=true
webView.settings.loadsImagesAutomatically=true
webView.settings.javaScriptCanOpenWindowsAutomatically=true
webView.settings.setSupportMultipleWindows(false)
webView.webViewClient=object:WebViewClient(){
override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest):Boolean{
return false
}
override fun onPageFinished(view:WebView,url:String){
CookieManager.getInstance().flush()
super.onPageFinished(view,url)
}
}
webView.webChromeClient=WebChromeClient()
webView.loadUrl(dashboardUrl)
}
override fun onPause(){
CookieManager.getInstance().flush()
super.onPause()
}
override fun onStop(){
CookieManager.getInstance().flush()
super.onStop()
}
override fun onBackPressed(){
if(webView.canGoBack())webView.goBack()else super.onBackPressed()
}
override fun onDestroy(){
webView.loadUrl("about:blank")
webView.clearHistory()
webView.destroy()
super.onDestroy()
}
}